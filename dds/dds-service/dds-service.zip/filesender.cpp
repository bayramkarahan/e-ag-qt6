#include "filesender.h"

#include <QFile>
#include <QFileInfo>

FileSender::FileSender(QObject *parent)
    : QObject(parent)
{
    log("FileSender START");
}

void FileSender::sendFile(FileMeta fileMeta,quint16 port,QString savePath)
{
    QFile file(fileMeta.sourcePath);

    if(!file.open(QIODevice::ReadOnly))
        return;

    sharedBuffer = file.readAll();

    QFileInfo info(fileMeta.sourcePath);

    sharedFilename = info.fileName();
    sharedSavePath = savePath;

    for(QString ip : fileMeta.allowedClients)
    {
        QTcpSocket *socket = new QTcpSocket(this);

        TransferSession *session =new TransferSession();
        session->fileMeta=fileMeta;
        session->socket = socket;
        session->ip = ip;
        session->filename = sharedFilename;
        session->totalSize = sharedBuffer.size();
        sessions.append(session);

        connect(socket,&QTcpSocket::connected,this,&FileSender::socketConnected);
        connect(socket,&QTcpSocket::bytesWritten,this,&FileSender::socketBytesWritten);
        connect(socket,&QTcpSocket::disconnected,this,&FileSender::socketDisconnected);
        connect(socket,
                &QTcpSocket::errorOccurred,
                this,
                [](QAbstractSocket::SocketError e)
                {
                    qDebug() << "TCP ERROR" << e;
                });
        socket->connectToHost(ip,port);
    }
}

void FileSender::socketConnected()
{
    QTcpSocket *socket =(QTcpSocket*)sender();

    for(TransferSession *session : sessions)
    {
        if(session->socket == socket)
        {
            QString header =
                QString("FILE|%1|%2|%3\n").arg(session->fileMeta.transferId).arg(sharedFilename).arg(sharedBuffer.size());
            socket->write(header.toUtf8());
            session->headerSent = true;
            ///emit clientConnected(session->ip);
            sendNextChunk(session);
            break;
        }
    }
}

void FileSender::socketBytesWritten(qint64)
{
    QTcpSocket *socket =
        (QTcpSocket*)sender();

    for(TransferSession *session : sessions)
    {
        if(session->socket == socket)
        {
            if(session->completed)
                return;

            sendNextChunk(session);

            break;
        }
    }
}

void FileSender::sendNextChunk(TransferSession *session)
{
    if(session->offset >= sharedBuffer.size())
    {
        if(!session->completed)
        {
            session->completed = true;
            emit transferFinished(session->fileMeta.transferId,session->ip,session->fileMeta.sourceBaseName);
            session->socket->disconnectFromHost();
        }

        return;
    }

    qint64 remaining = sharedBuffer.size() - session->offset;
    qint64 size = qMin((qint64)chunkSize,remaining);
    qint64 written =session->socket->write(sharedBuffer.constData()+ session->offset,size);

    if(written <= 0)
        return;

    session->offset += written;
    /*int percent =(double)session->offset*100.0/ sharedBuffer.size();
    int step = (percent / 10) * 10;

    if(step != session->lastProgress)
    {
        session->lastProgress = step;
        emit transferProgress(session->ip,session->offset, sharedBuffer.size(),step);
    }*/

}

void FileSender::socketDisconnected()
{
    QTcpSocket *socket =
        (QTcpSocket*)sender();

    socket->deleteLater();
}
